/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Me
 */
public class Pelanggan {
    public String noidplg;
    public String jenisidplg;
    public String namaplg;
    public String alamatplg;
    public String tgllahir;
    public String notlpplg;

    public String getNoidplg() {
        return noidplg;
    }

    public void setNoidplg(String noidplg) {
        this.noidplg = noidplg;
    }

    public String getJenisidplg() {
        return jenisidplg;
    }

    public void setJenisidplg(String jenisidplg) {
        this.jenisidplg = jenisidplg;
    }

    public String getNamaplg() {
        return namaplg;
    }

    public void setNamaplg(String namaplg) {
        this.namaplg = namaplg;
    }

    public String getAlamatplg() {
        return alamatplg;
    }

    public void setAlamatplg(String alamatplg) {
        this.alamatplg = alamatplg;
    }

    public String getTgllahir() {
        return tgllahir;
    }

    public void setTgllahir(String tgllahir) {
        this.tgllahir = tgllahir;
    }

    public String getNotlpplg() {
        return notlpplg;
    }

    public void setNotlpplg(String notlpplg) {
        this.notlpplg = notlpplg;
    }
    
}
