/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Me
 */
public class BuktiSewa {
    private String nosewa;
    private String tglsewa;
    private String tglkembali;
    private String noidplg;
    private String namaplg;
    private String kdnpwp;
    private String nmcabang;
    private String kdmobil;
    private String nmmobil;
    private Integer hargasewa;
    private Integer qty;
    private Integer jmlmobil;
    private Integer total;

    public String getNosewa() {
        return nosewa;
    }

    public void setNosewa(String nosewa) {
        this.nosewa = nosewa;
    }

    public String getTglsewa() {
        return tglsewa;
    }

    public void setTglsewa(String tglsewa) {
        this.tglsewa = tglsewa;
    }

    public String getTglkembali() {
        return tglkembali;
    }

    public void setTglkembali(String tglkembali) {
        this.tglkembali = tglkembali;
    }

    public String getNoidplg() {
        return noidplg;
    }

    public void setNoidplg(String noidplg) {
        this.noidplg = noidplg;
    }

    public String getNamaplg() {
        return namaplg;
    }

    public void setNamaplg(String namaplg) {
        this.namaplg = namaplg;
    }

    public String getKdnpwp() {
        return kdnpwp;
    }

    public void setKdnpwp(String kdnpwp) {
        this.kdnpwp = kdnpwp;
    }

    public String getNmcabang() {
        return nmcabang;
    }

    public void setNmcabang(String nmcabang) {
        this.nmcabang = nmcabang;
    }

    public String getKdmobil() {
        return kdmobil;
    }

    public void setKdmobil(String kdmobil) {
        this.kdmobil = kdmobil;
    }

    public String getNmmobil() {
        return nmmobil;
    }

    public void setNmmobil(String nmmobil) {
        this.nmmobil = nmmobil;
    }

    public Integer getHargasewa() {
        return hargasewa;
    }

    public void setHargasewa(Integer hargasewa) {
        this.hargasewa = hargasewa;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Integer getJmlmobil() {
        return jmlmobil;
    }

    public void setJmlmobil(Integer jmlmobil) {
        this.jmlmobil = jmlmobil;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    
}
