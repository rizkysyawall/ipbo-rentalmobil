/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author panji
 */
public class Mobil {
    private String kdmobil;
    private String merek;
    private String model;
    private Integer thnmobil;
    private String nonpwp;
    private String nmcabang;
    private Integer jmlstok;
    private Integer jmlmobil;
    private Integer hargasewa;

    public Integer getHargasewa() {
        return hargasewa;
    }

    public void setHargasewa(Integer hargasewa) {
        this.hargasewa = hargasewa;
    }

    public String getKdmobil() {
        return kdmobil;
    }

    public void setKdmobil(String kdmobil) {
        this.kdmobil = kdmobil;
    }

    public String getMerek() {
        return merek;
    }

    public void setMerek(String merk) {
        this.merek = merk;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getThnmobil() {
        return thnmobil;
    }

    public void setThnmobil(Integer thnmobil) {
        this.thnmobil = thnmobil;
    }

    public String getNonpwp() {
        return nonpwp;
    }

    public void setNonpwp(String kdnpwp) {
        this.nonpwp = kdnpwp;
    }

    public String getNmcabang() {
        return nmcabang;
    }

    public void setNmcabang(String namacabang) {
        this.nmcabang = namacabang;
    }

    public Integer getJmlstok() {
        return jmlstok;
    }

    public void setJmlstok(Integer jmlstok) {
        this.jmlstok = jmlstok;
    }

    public Integer getJmlmobil() {
        return jmlmobil;
    }

    public void setJmlmobil(Integer jmlmobil) {
        this.jmlmobil = jmlmobil;
    }

    public String getKatakunci() {
        return katakunci;
    }

    public void setKatakunci(String katakunci) {
        this.katakunci = katakunci;
    }
    private String katakunci;

    
    
}
