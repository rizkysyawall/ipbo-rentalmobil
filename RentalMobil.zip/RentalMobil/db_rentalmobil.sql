﻿# Host: localhost  (Version: 5.5.5-10.1.16-MariaDB)
# Date: 2016-12-22 14:31:29
# Generator: MySQL-Front 5.2  (Build 5.66)

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

USE `db_rentalmobil`;

#
# Source for table "buktisewa"
#

DROP TABLE IF EXISTS `buktisewa`;
CREATE TABLE `buktisewa` (
  `nobsm` varchar(255) NOT NULL,
  `nmcabang` varchar(255) DEFAULT NULL,
  `kdmobil` varchar(255) DEFAULT NULL,
  `merek` varchar(255) DEFAULT NULL,
  `hrgsewa` int(2) DEFAULT NULL,
  `qty` int(2) DEFAULT NULL,
  `total` varchar(50) DEFAULT NULL,
  `tglsewa` date DEFAULT '0000-00-00',
  `tglkembali` date DEFAULT '0000-00-00',
  `nonpwp` varchar(255) DEFAULT NULL,
  `noidplg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`nobsm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "buktisewa"
#


#
# Source for table "detilsewa"
#

DROP TABLE IF EXISTS `detilsewa`;
CREATE TABLE `detilsewa` (
  `nobsm` varchar(20) NOT NULL DEFAULT '',
  `kdmobil` varchar(255) DEFAULT NULL,
  `hrgsewa` int(11) DEFAULT NULL,
  `jmlsewa` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# Data for table "detilsewa"
#


#
# Source for table "mobil"
#

DROP TABLE IF EXISTS `mobil`;
CREATE TABLE `mobil` (
  `kdmobil` varchar(15) NOT NULL DEFAULT '',
  `merek` varchar(20) NOT NULL DEFAULT '',
  `model` varchar(50) NOT NULL DEFAULT '',
  `thnbuat` year(4) NOT NULL DEFAULT '0000',
  `jmlmobil` int(5) DEFAULT NULL,
  `hrgsewa` int(11) NOT NULL DEFAULT '0',
  `nonpwp` varchar(20) DEFAULT NULL,
  `nmcabang` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kdmobil`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "mobil"
#

INSERT INTO `mobil` VALUES ('KM2.87-101','Ford','CVT(Continuously Variable Transmission)',2006,3,750000,'2.87-1','Jakarta Pusat'),('KM2.87-102','Mazda','CVT(Continuously Variable Transmission)',2008,2,600000,'2.87-1','Jakarta Pusat');

#
# Source for table "pelanggan"
#

DROP TABLE IF EXISTS `pelanggan`;
CREATE TABLE `pelanggan` (
  `noidplg` varchar(10) NOT NULL DEFAULT '',
  `jenisidplg` varchar(20) NOT NULL DEFAULT '',
  `nmplg` varchar(30) NOT NULL DEFAULT '',
  `alamatplg` varchar(30) NOT NULL DEFAULT '',
  `tgllahirplg` date NOT NULL DEFAULT '0000-00-00',
  `notlpplg` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`noidplg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "pelanggan"
#

INSERT INTO `pelanggan` VALUES ('1511500827','KARTU PELAJAR','Muhamad Rizky Syawalludin','Jl Pondok Serut 2 no 74','1997-02-17','089672839485');

#
# Source for table "rental"
#

DROP TABLE IF EXISTS `rental`;
CREATE TABLE `rental` (
  `nonpwp` varchar(11) NOT NULL DEFAULT '0',
  `nmcabang` varchar(20) NOT NULL DEFAULT '',
  `alamatrental` varchar(20) NOT NULL,
  `notlprental` varchar(15) NOT NULL DEFAULT '',
  `jmlstok` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nonpwp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "rental"
#

INSERT INTO `rental` VALUES ('1.67-1','Jakarta Barat','jl kebon jeruk no 45','021838383838',5),('2.87-1','Jakarta Pusat','jl pancoran raya','021748495623',1);

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
